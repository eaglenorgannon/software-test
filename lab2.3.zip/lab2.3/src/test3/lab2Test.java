package test3;

import static org.junit.Assert.*;

import java.io.File;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class lab2Test {

	@Before
	
	@After
	
	@Test
	public void test() {
		lab2 test=new lab2();
		List<String> dataList=lab2.importCsv(new File("E:\\tony\\university-third-spring\\��������\\lab2\\inputgit.csv"));

        	
        int count=dataList.size()-1;
        for (int i=1; i<=count; i++)    
        {
      	  String s=new String(dataList.get(i));	  
      	  assertEquals(test.getUrl(s),test.getgit(test.getid(s))); 
        }   	
      		
	}
}