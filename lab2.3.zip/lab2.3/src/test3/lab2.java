package test3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream; 
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream; 
import java.io.OutputStreamWriter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;


import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;


import jxl.Cell;     
import jxl.CellType;    
import jxl.Sheet;    
import jxl.Workbook;    
import jxl.write.Label;   

public class lab2 {
	WebDriver dri;
	private String baseUrl;
    public static List<String> importCsv(File file){
        List<String> dataList=new ArrayList<String>();
        
        BufferedReader br=null;
        try { 
            br = new BufferedReader(new FileReader(file));
            String line = ""; 
            while ((line = br.readLine()) != null) { 
                dataList.add(line);
            }
        }catch (Exception e) {
        }finally{
            if(br!=null){
                try {
                    br.close();
                    br=null;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
 
        return dataList;
    }
    
    public String getid(String data)
	{
		String number=data.substring(0,10);
  	    return number;
	}
	
	public String getUrl(String data)
	{
  	    int point1=data.indexOf(",")+1;
  	    int point2=data.indexOf(",",point1);
  	    String url=data.substring(point2+1,data.length());
  	    return url;
	}
	
	
	public String getgit(String sid)
	{
		baseUrl = "http://121.193.130.195:8080";
		String spw=sid.substring(4,sid.length());
		System.setProperty("webdriver.firefox.bin", "D:\\Ӧ�ó���\\��������\\firefox.exe");
		System.setProperty("webdriver.firefox.marionette","E:\\tony\\university-third-spring\\��������\\lab2\\geckodriver-v0.15.0-win64\\geckodriver.exe");
	  	dri = new FirefoxDriver();
  	    dri.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  	    dri.get(baseUrl + "/");
  	    dri.findElement(By.id("name")).clear();
  	    dri.findElement(By.id("name")).sendKeys(sid);
  	    dri.findElement(By.id("pwd")).clear();
  	    dri.findElement(By.id("pwd")).sendKeys(spw);
  	    dri.findElement(By.id("submit")).click();
  	    String git=dri.findElement(By.xpath("//tr[3]/td[2]")).getText();
  	    dri.close();  
  	    return git;	
	}
	
}


